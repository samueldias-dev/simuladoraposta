# 🎯 Guia Iniciante - Como Publicar seu Site no GitHub Pages

Não se preocupe! Vou explicar tudo bem simples, passo a passo.

---

## 📌 O que você precisa saber

**GitHub** é um serviço que armazena seu código na nuvem. **GitHub Pages** é um serviço do GitHub que publica seu site automaticamente.

Pense assim:
- **Seu computador** = Onde você escreve o código
- **GitHub** = Um servidor na nuvem que guarda seu código
- **GitHub Pages** = Publica seu site para o mundo acessar

---

## ✅ Passo 1: Verificar se você tem uma conta GitHub

1. Vá para [github.com](https://github.com)
2. Se você já tem conta, faça login
3. Se não tem, clique em **"Sign up"** e crie uma conta (é grátis!)

---

## 📂 Passo 2: Criar um repositório no GitHub

Um repositório é como uma pasta que guarda seu projeto.

1. Acesse [github.com/new](https://github.com/new)
2. Preencha assim:
   - **Repository name**: `simulador-aposta` (ou outro nome que quiser)
   - **Description**: "Simulador profissional de gestão de banca" (opcional)
   - **Public** ✅ (IMPORTANTE: Marque como público!)
   - Deixe o resto como está
3. Clique em **"Create repository"**

Pronto! Você tem um repositório vazio no GitHub.

---

## 💻 Passo 3: Fazer Push do Código (Enviar seu projeto para GitHub)

Agora você vai enviar o código do seu computador para o GitHub.

### Se você tem Git instalado:

Abra o **Terminal** (ou **PowerShell** no Windows) e execute estes comandos:

```bash
cd /home/ubuntu/simulador-aposta
git config user.name "Seu Nome"
git config user.email "seu-email@gmail.com"
git remote set-url origin https://github.com/SEU-USUARIO/simulador-aposta.git
git add .
git commit -m "Primeira versão do simulador"
git push origin main
```

**Substitua:**
- `SEU-USUARIO` pelo seu usuário do GitHub
- `Seu Nome` pelo seu nome
- `seu-email@gmail.com` pelo seu email do GitHub

### Se aparecer um aviso pedindo senha:

1. Vá para [github.com/settings/tokens](https://github.com/settings/tokens)
2. Clique em **"Generate new token"** → **"Generate new token (classic)"**
3. Marque a caixa **"repo"**
4. Clique em **"Generate token"**
5. **Copie o token** (é uma sequência de letras e números)
6. Quando o terminal pedir senha, **cole o token** e pressione Enter

---

## 🚀 Passo 4: Ativar GitHub Pages

Agora você vai ativar o GitHub Pages para publicar seu site.

1. Vá para seu repositório no GitHub
   - URL: `https://github.com/SEU-USUARIO/simulador-aposta`

2. Clique na aba **"Settings"** (engrenagem no topo)
   ![Settings](https://i.imgur.com/abc123.png)

3. No menu esquerdo, clique em **"Pages"**
   ![Pages](https://i.imgur.com/def456.png)

4. Em **"Source"**, selecione:
   - **Deploy from a branch**
   - Branch: `gh-pages`
   - Folder: `/ (root)`

5. Clique em **"Save"**

---

## ⏳ Passo 5: Aguardar o Deploy

1. Vá para a aba **"Actions"** do seu repositório
2. Você verá um workflow chamado **"Deploy to GitHub Pages"** em execução
3. Aguarde até aparecer ✅ (verde)
4. Pode levar 1-5 minutos

---

## 🎉 Pronto! Seu site está online!

Quando o deploy terminar, seu site estará disponível em:

```
https://SEU-USUARIO.github.io/simulador-aposta/
```

**Substitua `SEU-USUARIO` pelo seu usuário do GitHub**

---

## 🔄 Fazer Mudanças no Futuro

Sempre que quiser fazer mudanças:

1. Edite os arquivos no seu computador
2. Abra o Terminal e execute:
   ```bash
   cd /home/ubuntu/simulador-aposta
   git add .
   git commit -m "Descrição da mudança"
   git push origin main
   ```
3. O site será atualizado automaticamente em alguns minutos!

---

## ❓ Dúvidas Comuns

**P: Quanto custa?**
R: Totalmente grátis! GitHub Pages é gratuito para repositórios públicos.

**P: Quanto tempo leva para o site ficar online?**
R: Normalmente 1-5 minutos após fazer push.

**P: Posso usar um domínio próprio?**
R: Sim! Você pode configurar um domínio customizado nas configurações do GitHub Pages.

**P: O que é "main"?**
R: É o nome da branch principal do seu projeto (tipo a versão oficial).

**P: O que é "gh-pages"?**
R: É a branch que o GitHub Pages usa para publicar seu site.

---

## 🆘 Se algo der errado

**Erro: "Permission denied"**
- Verifique se o token foi gerado corretamente
- Tente gerar um novo token

**Erro: "Repository not found"**
- Verifique se a URL está correta: `https://github.com/SEU-USUARIO/simulador-aposta`
- Substitua `SEU-USUARIO` pelo seu usuário real

**Site mostra 404**
- Verifique se GitHub Pages está ativado
- Verifique se a branch é `gh-pages`

---

## 📞 Precisa de ajuda?

Se algo não funcionar, me avise! Posso ajudar passo a passo.

Boa sorte! 🚀
