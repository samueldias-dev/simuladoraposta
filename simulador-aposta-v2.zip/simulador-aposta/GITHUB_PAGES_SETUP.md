# Configuração GitHub Pages - OddsLab Simulador

Este projeto está configurado para ser publicado automaticamente no GitHub Pages.

## 📋 Pré-requisitos

1. Você já tem o repositório no GitHub
2. O repositório é **público** (GitHub Pages requer isso no plano gratuito)

## 🚀 Passos para Ativar

### 1. **Fazer Push do Código**
Se você ainda não fez push do código para o GitHub:

```bash
cd /home/ubuntu/simulador-aposta
git add .
git commit -m "Configuração para GitHub Pages"
git push origin main
```

### 2. **Ativar GitHub Pages**

1. Vá para seu repositório no GitHub
2. Clique em **Settings** → **Pages**
3. Em "Source", selecione:
   - **Deploy from a branch**
   - Branch: `gh-pages`
   - Folder: `/ (root)`
4. Clique em **Save**

### 3. **Verificar o Workflow**

1. Vá para a aba **Actions** do seu repositório
2. Você verá o workflow "Deploy to GitHub Pages" em execução
3. Quando terminar (✅), seu site estará disponível em:

```
https://seu-usuario.github.io/simulador-aposta/
```

## 🔄 Como Funciona

- **Trigger**: Cada push para a branch `main` dispara o deploy automaticamente
- **Build**: O GitHub Actions executa `pnpm install` e `pnpm run build`
- **Deploy**: Os arquivos são automaticamente enviados para a branch `gh-pages`
- **Publicação**: GitHub Pages publica o conteúdo em seu domínio

## 📝 Configurações Aplicadas

- ✅ `vite.config.ts` - Configurado para GitHub Pages com base path dinâmica
- ✅ `.github/workflows/deploy.yml` - Workflow automático de deploy
- ✅ `package.json` - Script de build otimizado

## 🔧 Para Fazer Mudanças

Sempre que você fizer mudanças:

```bash
git add .
git commit -m "Sua mensagem"
git push origin main
```

O deploy acontecerá automaticamente! Você pode acompanhar em **Actions**.

## ⚠️ Troubleshooting

**Problema**: Site mostra 404
- **Solução**: Verifique se GitHub Pages está ativado e apontando para `gh-pages` branch

**Problema**: Estilos não carregam
- **Solução**: Isso significa que a base path não está correta. Verifique `vite.config.ts`

**Problema**: Workflow falha
- **Solução**: Verifique os logs em **Actions** → seu workflow → ver detalhes

## 📚 Recursos

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Vite Deployment Guide](https://vitejs.dev/guide/static-deploy.html#github-pages)
